"""主程序入口 - 处理大文件夹下的小文件夹结构"""

import os
import pandas as pd
import numpy as np
from tqdm import tqdm

from config import REDUCTION_RATIO, EXDA_PARAMS, SAMPLING_METHODS, KEY_METRICS
from exda_model import ExDA
from data_loader import (
    load_data_from_csv, 
    create_small_dataset, 
    evaluate_model_comprehensive, 
    apply_sampling_methods
)
from sklearn.linear_model import LogisticRegression

def run_core_experiment(folder_path, target_column='defect', output_file='results.csv'):
    """
    运行核心实验流程：
    1. 读取数据
    2. 删减数据
    3. 训练ExDA
    4. 采样
    5. 训练模型
    6. 测试
    """
    csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]
    
    if len(csv_files) < 2:
        print(f"文件夹 {folder_path} 中CSV文件数量不足")
        return None
    
    results = []
    
    # 使用tqdm显示训练进度
    for train_file in tqdm(csv_files, desc=f"训练数据集 - {os.path.basename(folder_path)}"):
        try:
            # 1. 读取数据
            X_train_full, y_train_full, _ = load_data_from_csv(
                os.path.join(folder_path, train_file), target_column
            )
            
            # 2. 删减数据 - 创建小数据集
            X_train_small, y_train_small = create_small_dataset(
                X_train_full, y_train_full, reduction_ratio=REDUCTION_RATIO
            )
            
            # 3. 训练ExDA模型
            exda = ExDA(**EXDA_PARAMS)
            exda.fit(X_train_small, y_train_small)
            
            # 生成增强数据
            X_train_aug, y_train_aug = exda.augment(X_train_small, y_train_small)
            
            # 4. 采样 - 应用其他采样方法
            sampling_results = apply_sampling_methods(X_train_small, y_train_small)
            
            # 训练对比模型
            # 完整数据集模型
            full_model = LogisticRegression(random_state=42, max_iter=1000)
            full_model.fit(X_train_full, y_train_full)
            
            # 小数据集模型
            small_model = LogisticRegression(random_state=42, max_iter=1000)
            small_model.fit(X_train_small, y_train_small)
            
            # 增强模型
            aug_model = LogisticRegression(random_state=42, max_iter=1000)
            aug_model.fit(X_train_aug, y_train_aug)
            
            # 采样方法模型
            sampling_models = {}
            for method in SAMPLING_METHODS:
                if method in sampling_results:
                    model = LogisticRegression(random_state=42, max_iter=1000)
                    model.fit(sampling_results[method]['X'], sampling_results[method]['y'])
                    sampling_models[method] = model
            
            # 测试所有其他文件
            test_files = [f for f in csv_files if f != train_file]
            for test_file in tqdm(test_files, desc=f"测试 {train_file}", leave=False):
                try:
                    # 加载测试数据
                    X_test, y_test, _ = load_data_from_csv(
                        os.path.join(folder_path, test_file), target_column
                    )
                    
                    # 5. 训练模型 & 6. 测试 - 计算所有模型性能
                    full_metrics = evaluate_model_comprehensive(X_train_full, y_train_full, X_test, y_test)
                    small_metrics = evaluate_model_comprehensive(X_train_small, y_train_small, X_test, y_test)
                    aug_metrics = evaluate_model_comprehensive(X_train_aug, y_train_aug, X_test, y_test)
                    
                    sampling_metrics = {}
                    for method, model in sampling_models.items():
                        sampling_metrics[method] = evaluate_model_comprehensive(
                            sampling_results[method]['X'], sampling_results[method]['y'], X_test, y_test
                        )
                    
                    # 记录结果
                    result = {
                        'train_file': train_file,
                        'test_file': test_file,
                        'dataset_folder': os.path.basename(folder_path),
                        'reduction_ratio': REDUCTION_RATIO,
                        
                        # 性能指标
                        **{f'full_{k}': v for k, v in full_metrics.items()},
                        **{f'small_{k}': v for k, v in small_metrics.items()},
                        **{f'aug_{k}': v for k, v in aug_metrics.items()},
                    }
                    
                    # 采样方法性能
                    for method in sampling_metrics.keys():
                        result.update({f'{method}_{k}': v for k, v in sampling_metrics[method].items()})
                    
                    # 样本数量信息
                    result.update({
                        'full_samples': len(y_train_full),
                        'full_defect_ratio': np.sum(y_train_full)/len(y_train_full),
                        'small_samples': len(y_train_small),
                        'small_defect_ratio': np.sum(y_train_small)/len(y_train_small),
                        'aug_samples': len(y_train_aug),
                        'aug_defect_ratio': np.sum(y_train_aug)/len(y_train_aug),
                        'test_samples': len(y_test),
                        'test_defect_ratio': np.sum(y_test)/len(y_test),
                    })
                    
                    # 采样方法样本数量
                    for method in sampling_results.keys():
                        result.update({
                            f'{method}_samples': len(sampling_results[method]['y']),
                            f'{method}_defect_ratio': np.sum(sampling_results[method]['y'])/len(sampling_results[method]['y'])
                        })
                    
                    results.append(result)
                    
                except Exception as e:
                    print(f"测试文件 {test_file} 处理失败: {str(e)}")
                    continue
            
        except Exception as e:
            print(f"训练文件 {train_file} 处理失败: {str(e)}")
            continue
    
    # 保存结果
    if results:
        results_df = pd.DataFrame(results)
        results_df.to_csv(output_file, index=False)
        print(f"数据集 {os.path.basename(folder_path)} 实验完成，结果保存至: {output_file}")
        
        # 打印简要统计
        print_summary_statistics(results_df, folder_path)
    
    return results

def print_summary_statistics(results_df, folder_path):
    """打印简要统计信息"""
    print(f"\n=== 数据集 {os.path.basename(folder_path)} 实验统计摘要 ===")
    
    # 计算平均性能
    for method in ['full', 'small', 'aug'] + SAMPLING_METHODS:
        f1_scores = []
        for metric in KEY_METRICS:
            col_name = f'{method}_{metric}'
            if col_name in results_df.columns:
                if metric == 'F1':
                    f1_scores.extend(results_df[col_name].values)
        
        if f1_scores:
            avg_f1 = np.mean(f1_scores)
            std_f1 = np.std(f1_scores)
            print(f"{method:15} - 平均F1: {avg_f1:.3f} (±{std_f1:.3f})")

def process_all_datasets(parent_folder_path, target_column='defect'):
    """
    处理父文件夹下的所有子文件夹
    """
    # 获取父文件夹下的所有子文件夹
    dataset_folders = [f for f in os.listdir(parent_folder_path) 
                      if os.path.isdir(os.path.join(parent_folder_path, f))]
    
    all_results = []
    
    # 使用tqdm显示总体进度
    for dataset_folder in tqdm(dataset_folders, desc="处理数据集文件夹"):
        folder_path = os.path.join(parent_folder_path, dataset_folder)
        
        # 为每个数据集创建结果目录
        results_dir = os.path.join(folder_path, "results")
        os.makedirs(results_dir, exist_ok=True)
        
        # 运行核心实验
        output_file = os.path.join(results_dir, f'exda_results_{dataset_folder}.csv')
        results = run_core_experiment(
            folder_path=folder_path,
            target_column=target_column,
            output_file=output_file
        )
        
        if results:
            # 为每个结果添加数据集名称
            for result in results:
                result['dataset_name'] = dataset_folder
            all_results.extend(results)
    
    # 汇总所有结果
    if all_results:
        summary_df = pd.DataFrame(all_results)
        summary_file = os.path.join(parent_folder_path, "all_datasets_summary.csv")
        summary_df.to_csv(summary_file, index=False)
        print(f"\n=== 所有数据集实验完成 ===")
        print(f"汇总结果保存至: {summary_file}")
        
        # 打印总体统计
        print_overall_summary(summary_df)
    
    return all_results

def print_overall_summary(summary_df):
    """打印总体统计信息"""
    print("\n=== 总体实验统计摘要 ===")
    
    # 按数据集分组统计
    datasets = summary_df['dataset_name'].unique()
    
    for dataset in datasets:
        dataset_data = summary_df[summary_df['dataset_name'] == dataset]
        print(f"\n数据集: {dataset}")
        
        # 计算每个方法的平均F1
        for method in ['full', 'small', 'aug']:
            f1_scores = []
            for metric in KEY_METRICS:
                col_name = f'{method}_{metric}'
                if col_name in dataset_data.columns and metric == 'F1':
                    f1_scores.extend(dataset_data[col_name].values)
            
            if f1_scores:
                avg_f1 = np.mean(f1_scores)
                print(f"  {method:15} - 平均F1: {avg_f1:.3f}")

if __name__ == "__main__":
    # 设置父文件夹路径（包含多个子文件夹，每个子文件夹是一个数据集）
    parent_folder_path = "./Datasets"  # 修改为您的父文件夹路径
    
    # 处理所有数据集
    all_results = process_all_datasets(
        parent_folder_path=parent_folder_path,
        target_column='class'  # 根据实际数据修改目标列名
    )