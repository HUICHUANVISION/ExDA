"""数据加载和处理模块"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (precision_score, recall_score, f1_score, roc_auc_score, 
                           matthews_corrcoef, balanced_accuracy_score, accuracy_score,
                           precision_recall_curve, auc)
import warnings
warnings.filterwarnings('ignore')

def load_data_from_csv(file_path, target_column='defect'):
    """
    从CSV文件加载数据
    """
    data = pd.read_csv(file_path)
    
    if target_column not in data.columns:
        target_column = data.columns[-1]
    
    X = data.drop(columns=[target_column])
    y = data[target_column]
    
    feature_names = X.columns.tolist()
    X = X.values
    y = y.values
    
    return X, y, feature_names

def create_small_dataset(X, y, reduction_ratio=0.5, random_state=42):
    """
    通过随机删除样本来创建小数据集
    """
    np.random.seed(random_state)
    
    n_samples = len(y)
    n_keep = int(n_samples * reduction_ratio)
    keep_indices = np.random.choice(n_samples, n_keep, replace=False)
    
    X_small = X[keep_indices]
    y_small = y[keep_indices]
    
    return X_small, y_small

def compute_comprehensive_metrics(y_true, y_pred, y_prob):
    """计算全面的评估指标"""
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    
    auc_roc = roc_auc_score(y_true, y_prob) if len(np.unique(y_true)) > 1 else 0.5
    
    precision_curve, recall_curve, _ = precision_recall_curve(y_true, y_prob)
    auc_pr = auc(recall_curve, precision_curve)
    
    mcc = matthews_corrcoef(y_true, y_pred)
    balanced_acc = balanced_accuracy_score(y_true, y_pred)
    
    tp = np.sum((y_true == 1) & (y_pred == 1))
    tn = np.sum((y_true == 0) & (y_pred == 0))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    gmean = np.sqrt(sensitivity * specificity)
    
    false_alarm_rate = fp / (fp + tn) if (fp + tn) > 0 else 0
    
    metrics = {
        'ACC': accuracy,
        'Precision': precision,
        'Recall': recall,
        'F1': f1,
        'AUC-ROC': auc_roc,
        'PR-AUC': auc_pr,
        'MCC': mcc,
        'G-mean': gmean,
        'Balanced_ACC': balanced_acc,
        'False_Alarm_Rate': false_alarm_rate
    }
    
    return metrics

def evaluate_model_comprehensive(X_train, y_train, X_test, y_test):
    """全面评估模型性能"""
    from sklearn.utils import shuffle
    X_train, y_train = shuffle(X_train, y_train)
    model = LogisticRegression(random_state=42, max_iter=1000)

    model.fit(X_train, y_train)
    
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]
    
    metrics = compute_comprehensive_metrics(y_test, y_pred, y_prob)
    return metrics

def apply_sampling_methods(X, y, target_ratio=0.5, random_state=42):
    """
    应用不同的采样方法（简化版）
    """
    from imblearn.under_sampling import RandomUnderSampler
    from imblearn.over_sampling import RandomOverSampler, SMOTE, ADASYN
    
    sampling_results = {}
    
    # 计算当前正负样本数量
    positive_count = np.sum(y == 1)
    negative_count = np.sum(y == 0)
    current_ratio = positive_count / len(y) if len(y) > 0 else 0
    
    # 1. 不采样 (基线)
    sampling_results['no_sampling'] = {'X': X, 'y': y}

    # 各种采样方法的实现
    sampling_techniques = {
        'RUS': (RandomUnderSampler, current_ratio > target_ratio),
        'ROS': (RandomOverSampler, current_ratio < target_ratio),
        'SMOTE': (SMOTE, current_ratio < target_ratio),
        'ADASYN': (ADASYN, current_ratio < target_ratio),
    }
    
    for method_name, (sampler_class, should_apply) in sampling_techniques.items():
        try:
            if should_apply:
                sampler = sampler_class(sampling_strategy=target_ratio, random_state=random_state)
                X_resampled, y_resampled = sampler.fit_resample(X, y)
                sampling_results[method_name] = {'X': X_resampled, 'y': y_resampled}
            else:
                sampling_results[method_name] = {'X': X, 'y': y}
                    
        except Exception as e:
            sampling_results[method_name] = {'X': X, 'y': y}
    
    return sampling_results