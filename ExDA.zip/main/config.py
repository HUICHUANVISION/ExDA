"""配置参数文件"""

# 实验参数
REDUCTION_RATIO = 0.3
AUGMENTATION_PERCENTAGE = 0.3
TARGET_RATIO = 0.3
RANDOM_STATE = 42

# ExDA模型参数
EXDA_PARAMS = {
    'lambda_param': 0.5,
    'k_top_features': 0.25,
    'latent_dim': 32,
    'hidden_dim': 64,
    'lr': 1e-3,
    'epochs': 50,
    'batch_size': 16,
    'augmentation_percentage': AUGMENTATION_PERCENTAGE,
    'target_ratio': TARGET_RATIO
}

# 采样方法列表
SAMPLING_METHODS = [
    'no_sampling', 'RUS', 'ROS', 'SMOTE', 'ADASYN', 'BorderlineSMOTE',
    'SVMSMOTE', 'KMeansSMOTE', 'SMOTEENN', 'SMOTETomek', 'MPOS'
]

# 评估指标
KEY_METRICS = [
    'ACC', 'Precision', 'Recall', 'F1', 'AUC-ROC', 'PR-AUC', 
    'MCC', 'G-mean', 'Balanced_ACC', 'False_Alarm_Rate'
]